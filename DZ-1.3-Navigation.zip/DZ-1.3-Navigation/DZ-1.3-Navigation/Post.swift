//
//  Post.swift
//  DZ-1.3-Navigation
//
//  Created by Denis Zozulya on 06.02.2023.
//

struct Post {
    var title: String
}


